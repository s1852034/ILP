package uk.ac.ed.inf.aqmaps;

public class Position {
	protected double lng;
	protected double lat;
	public Position(double lng, double lat) {
		super();
		this.lng = lng;
		this.lat = lat;
	}
	
}
