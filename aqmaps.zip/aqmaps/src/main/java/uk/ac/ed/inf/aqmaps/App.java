package uk.ac.ed.inf.aqmaps;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
//import java.util.Scanner;
import java.net.URI;

import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Geometry;
import com.mapbox.geojson.LineString;
import com.mapbox.geojson.Point;
import com.mapbox.geojson.Polygon;
import java.lang.reflect.Type;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class App 
{
	private static final HttpClient client = HttpClient.newHttpClient();
	protected final static double[][] lnglat = new double[33][2];//sensors
	private final static List<Feature> fl = new ArrayList<Feature>();
	private static FeatureCollection fcSensors;
	private static String[] category = new String[33]; //pass readings in
	private static double[] categorydouble = new double[33];
	private static String[][] properties = new String[33][3]; //[0]~location,[1]~rgb/marker,[2]~symbol
	protected static final double[][] polygon0 = new double[15][2];
	protected static final double[][] polygon1 = new double[5][2];
	protected static final double[][] polygon2 = new double[5][2];
	protected static final double[][] polygon3 = new double[11][2];
	protected static final double[] initial = new double[2];
	private static double[][] city1 = new double[35][2];//A->B->C->....->A
	private static double[][] city2 = new double[35][2];//empty
	private static Drone drone = new Drone();
	private static int[] visit = new int[35];
	private static List<Position> dronepath = new ArrayList<Position>();
	private static String[] sensorname = new String[33];
	private static String[] visitname = new String[33];//w3w for visit
	private static List<txt> txtstring = new ArrayList<txt>();
	private static _tour tour = new _tour(city1);
	private static _tour newTour = new _tour(city2);

	// get maps from webserver by passing args
	public static String ReadFile(String[] args) {
		initial[0] = Double.parseDouble(args[4]);
		initial[1] = Double.parseDouble(args[3]);
		//System.out.println(initial[0]);
		//System.out.println(initial[1]);
		try {
			var request = HttpRequest.newBuilder()
					.uri(URI.create("http://localhost:"+ args[6] +"/maps/" + args[2] + "/" + args[1] + "/" + args[0] + "/" + "air-quality-data.json"))
					.build();
			var response = client.send(request, BodyHandlers.ofString());
			//System.out.println(response.statusCode());
			//System.out.println(response.body());
			return response.body();
		}
		catch(IOException | InterruptedException e){
			e.printStackTrace();
			System.out.println("Fatal error: Unable to connect to " + "http://localhost:"+ args[6] +"/maps/" + args[2] + "/" + args[1] + "/" + args[0] + "/" + "air-quality-data.json" + " at port " + args[6] + ".");
			System.exit(1);
			return null;
		}
	}
	// from the air-quality-data.json, get object Sensor
	public static ArrayList<Sensor> fromJsonSensor(String x) {
		try {
			Type listType = new TypeToken<ArrayList<Sensor>>() {}.getType();
			ArrayList<Sensor> sensorList = new Gson().fromJson(x, listType);
			return sensorList;
		}
		catch (NumberFormatException e){
			e.printStackTrace();
			return null;
		}
	}
	// from the location in Sensor, get words from webserver
	public static String ReadCoordinates(String x, String[] args) {
		String[] w3w = new String[3];
		w3w = x.split("\\.");
		try {
			var request = HttpRequest.newBuilder()
					.uri(URI.create("http://localhost:"+ args[6] +"/words/" + w3w[0] + "/" + w3w[1] + "/" + w3w[2] + "/" + "details.json"))
					.build();
			var response = client.send(request, BodyHandlers.ofString());
			//System.out.println(response.statusCode());
			//System.out.println(response.body());
			return response.body();
		}
		catch(IOException | InterruptedException e){
			e.printStackTrace();
			System.out.println("Fatal error: Unable to connect to " + "http://localhost:"+ args[6] +"/words/" + w3w[0] + "/" + w3w[1] + "/" + w3w[2] + "/" + "details.json");
			System.exit(1);
			return null;
		}
	}
	//from details.json get the object Words
	public static Words fromJsonWords(String x) {
		try {
			var words = new Gson().fromJson(x, Words.class);
			return words;
		}
		catch (NumberFormatException e){
			e.printStackTrace();
			return null;
		}
	}
	//get the no fly zone from webserver
	public static String ReadGeojson(String[]args) {
		try {
			var request = HttpRequest.newBuilder()
					.uri(URI.create("http://localhost:"+ args[6] +"/buildings/no-fly-zones.geojson"))
					.build();
			var response = client.send(request, BodyHandlers.ofString());
			//System.out.println(response.statusCode());
			//System.out.println(response.body());
			return response.body();
		}
		catch(IOException | InterruptedException e){
			e.printStackTrace();
			System.out.println("Fatal error: Unable to connect to http://localhost:"+ args[6] +"/buildings/no-fly-zones.geojson.");
			System.exit(1);
			return null;
		}
	}
	
	//Geojson to lnglat
	public static void fromGeojson (String x) {
		try {
			var f = (FeatureCollection.fromJson(x)).features();
			for (int i = 0; i < f.size(); i ++) {
				var polygon = (Polygon)(f.get(i).geometry());
				var listofpoint = (polygon.coordinates()).get(0);
				//System.out.println(listofpoint.size());
				for (int j = 0; j < listofpoint.size(); j++ ) {
					//System.out.println(listofpoint.get(j).coordinates());
					if(i==0) {
						polygon0[j][0] = listofpoint.get(j).coordinates().get(0);
						polygon0[j][1] = listofpoint.get(j).coordinates().get(1);
					}
					else if(i==1) {
						polygon1[j][0] = listofpoint.get(j).coordinates().get(0);
						polygon1[j][1] = listofpoint.get(j).coordinates().get(1);
					}
					else if(i==2) {
						polygon2[j][0] = listofpoint.get(j).coordinates().get(0);
						polygon2[j][1] = listofpoint.get(j).coordinates().get(1);
					}
					else if(i==3) {
						polygon3[j][0] = listofpoint.get(j).coordinates().get(0);
						polygon3[j][1] = listofpoint.get(j).coordinates().get(1);
					}
				}
			}
		}
		catch (NumberFormatException e){
			e.printStackTrace();
		}
	}
	
	//categorise the feature of the points //[0]~location,[1]~rgb/marker,[2]~symbol
	public static void Category(ArrayList<Sensor> lst) {
		for (int i = 0; i < lst.size(); i++) {
			category[i] = lst.get(i).reading;
		}
		for (int i = 0; i < lst.size(); i++) {
			if (category[i] == "NaN" || category[i] == "null" || lst.get(i).battery<10) {
				category[i] = "-1";
			}
		}
		for (int i = 0; i < lst.size(); i++) {
			categorydouble[i] = Double.parseDouble(category[i]);
		}
		for (int i = 0; i < lst.size(); i++) {
			if(categorydouble[i] == -1) {
				properties[i][1] = "000000";
				properties[i][2] = "cross";
			}
			else if(Math.round((categorydouble[i]/32)-0.5) == 0) {
				properties[i][1] = "#00ff00";
				properties[i][2] = "lighthouse";
			}
			else if(Math.round((categorydouble[i]/32)-0.5) == 1) {
				properties[i][1] = "#40ff00";
				properties[i][2] = "lighthouse";
			}				
			else if(Math.round((categorydouble[i]/32)-0.5) == 2) {
				properties[i][1] = "#80ff00";
				properties[i][2] = "lighthouse";
			}				
			else if(Math.round((categorydouble[i]/32)-0.5) == 3) {
				properties[i][1] = "#c0ff00";
				properties[i][2] = "lighthouse";
			}				
			else if(Math.round((categorydouble[i]/32)-0.5) == 4) {
				properties[i][1] = "#ffc000";
				properties[i][2] = "danger";
			}				
			else if(Math.round((categorydouble[i]/32)-0.5) == 5) {
				properties[i][1] = "#ff8000";
				properties[i][2] = "danger";
			}				
			else if(Math.round((categorydouble[i]/32)-0.5) == 6) {
				properties[i][1] = "#ff4000";
				properties[i][2] = "danger";
			}				
			else if(Math.round((categorydouble[i]/32)-0.5) == 7) {
				properties[i][1] = "#ff0000";
				properties[i][2] = "danger";
			}
			//else if not visited
		}
		for (int i = 0; i < lst.size(); i++) {
			properties[i][0] = lst.get(i).location;
		}
		
	}
	
	//Algorithm
	public static void setpath() {
		city1[0]=initial;
		for(int i =0; i < lnglat.length;i++) {
			city1[i+1] = lnglat[i];
		}
		city1[lnglat.length + 1] = initial;
	}

	
	public static void TwoOptSwap( int i, int k ) 
	{
	    int size = tour.TourSize();
	 
	    // 1. take route[0] to route[i-1] and add them in order to new_route
	    for ( int c = 0; c <= i - 1; ++c )
	    {
	        newTour.SetCity( c, tour.GetCity( c ) );
	    }
	         
	    // 2. take route[i] to route[k] and add them in reverse order to new_route
	    int dec = 0;
	    for ( int c = i; c <= k; ++c )
	    {
	        newTour.SetCity( c, tour.GetCity( k - dec ) );
	        dec++;
	    }
	 
	    // 3. take route[k+1] to end and add them in order to new_route
	    for ( int c = k + 1; c < size; ++c )
	    {
	        newTour.SetCity( c, tour.GetCity( c ) );
	    }
	}
	
	public static void TwoOpt()
	{
	    // Get tour size
	    int size = tour.TourSize();
	 
	    //CHECK THIS!!      
	    for (int i=0;i<size;i++)
	    {
	           newTour.SetCity(i, tour.GetCity(i));
	    }
	 
	    // repeat until no improvement is made 
	    int improve = 0;
	    int iteration = 0;
	    double out = 0;
	 
	    while ( improve < 800 )
	    {
	        double best_distance = tour.TourDistance();
	 
	        for ( int i = 1; i < size - 2; i++ ) 
	        {
	            for ( int k = i + 1; k < size - 1; k++) 
	            {
	                TwoOptSwap( i, k );
	                iteration++;
	                double new_distance = newTour.TourDistance();
	 
	                if ( new_distance < best_distance ) 
	                {
	                    // Improvement found so reset
	                    improve = 0;
	                                                 
	                    for (int j=0;j<size;j++)
	                    {
	                        tour.SetCity(j, newTour.GetCity(j));
	                    }
	                         
	                    best_distance = new_distance;
	                    out = best_distance;
	                    System.out.println(iteration);
	                    System.out.println(best_distance);
	                    System.out.println(" ");
	                }
	            }
	        }
	 
	        improve ++;
	    }
	    System.out.println(out);
	}
	//visitname
	public static void setvisitname() {
		for (int i = 1; i < city1.length-1; i++) {
			for(int j = 0; j < lnglat.length;j++) {
				if((city1[i][0] == lnglat[j][0])&& (city1[i][1] == lnglat[j][1])){
					visitname[i-1] = sensorname[j];
					}
				}
		}
	}
	//drone path
	public static void dronepath(double[]initial) {
		drone.setCurrent(initial);
		int k=0;//count
		for(int i = 1; i < city1.length-1;i++) {
			while(visit[i]==0) {
				Position p = new Position(drone.getCurrent()[0],drone.getCurrent()[1]); 
				dronepath.add(p);
				var x = drone.getCurrent();
				drone.move(drone.getCurrent(),city1[i]);
				k++;
				if(_tour.Euclidean(drone.getCurrent(),city1[i]) < 0.00019) {
					visit[i] = 1;
					txt t = new txt(k,x,drone.getDirection(),drone.getCurrent(),visitname[i-1]);
					txtstring.add(t);
				}else {
					txt t = new txt(k,x,drone.getDirection(),drone.getCurrent(),"null");
					txtstring.add(t);
				}
				
			}
		}
		while(visit[city1.length-1]==0) {
			Position p = new Position(drone.getCurrent()[0],drone.getCurrent()[1]); 
			dronepath.add(p);
			var x = drone.getCurrent();
			drone.move(drone.getCurrent(),city1[city1.length-1]);
			k++;
			if(_tour.Euclidean(drone.getCurrent(),city1[city1.length-1]) < 0.0003) {
				Position p1 = new Position(drone.getCurrent()[0],drone.getCurrent()[1]); 
				dronepath.add(p1);
				visit[city1.length-1] = 1;
				txt t = new txt(k,x,drone.getDirection(),drone.getCurrent(),"null");
				txtstring.add(t);
			}else {
				txt t = new txt(k,x,drone.getDirection(),drone.getCurrent(),"null");
				txtstring.add(t);
			}
			
		}
	}
	
	
	//generate feature of sensor to pass to Geojson (fcSensors)
	public static void SensorMap(double[][] lnglat) {
		for (int i = 0; i < lnglat.length; i ++) {
			Point point = Point.fromLngLat( lnglat[i][0] , lnglat[i][1]);
			Feature feature = Feature.fromGeometry((Geometry)point);
			if(visit[i+1]==1) {
				feature.addStringProperty("location",properties[i][0]);
				feature.addStringProperty("rgb-string",properties[i][1]);
				feature.addStringProperty("marker-color",properties[i][1]);
				feature.addStringProperty("marker-symbol",properties[i][2]);
				fl.add(feature);
			}else {
				feature.addStringProperty("location",properties[i][0]);
				feature.addStringProperty("rgb-string","#aaaaaa");
				feature.addStringProperty("marker-color","#aaaaaa");
			}
		}
		List<Point> point1 = new ArrayList<Point>();
		for (int i = 0; i < dronepath.size() ;i++) {
			Point point = Point.fromLngLat(dronepath.get(i).lng,dronepath.get(i).lat);
			point1.add(point);
		}
		fl.add(Feature.fromGeometry((Geometry)(LineString.fromLngLats(point1))));
		fcSensors = FeatureCollection.fromFeatures(fl);
	}	
	

	//Create and Write file //geojson
	public static void CreateFile(String[] args) {
		try {
			File myfile = new File("readings-"+args[0]+"-"+args[1]+"-"+args[2]+".geojson");
		    if (myfile.createNewFile()) {
		        System.out.println("File created: " + myfile.getName());
		    } 
		    else {
		        System.out.println("File already exists.");
		    }			
		}
		catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	public static void WriteFile(String[] args) {
	    try {
	        FileWriter myWriter = new FileWriter("readings-"+args[0]+"-"+args[1]+"-"+args[2]+".geojson");
	        myWriter.write(fcSensors.toJson());
	        myWriter.flush();
	        myWriter.close();
	    } 
	    catch (IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	    }		
	}
	//create and write txt
	public static void CreateFiletxt(String[] args) {
		try {
			File myfile = new File("flightpath-"+args[0]+"-"+args[1]+"-"+args[2]+".txt");
		    if (myfile.createNewFile()) {
		        System.out.println("File created: " + myfile.getName());
		    } 
		    else {
		        System.out.println("File already exists.");
		    }			
		}
		catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	public static void WriteFiletxt(String[] args) {
	    try {
	        FileWriter myWriter = new FileWriter("flightpath-"+args[0]+"-"+args[1]+"-"+args[2]+".txt");
	        BufferedWriter bufWriter = new BufferedWriter(myWriter);
	        for (int i = 0; i < txtstring.size(); i++) {
		        bufWriter.write(txtstring.get(i).getCount()+","+txtstring.get(i).getCrr()[0]+","+txtstring.get(i).getCrr()[1]+","+txtstring.get(i).getAngle()+","+txtstring.get(i).getNxt()[0]+","+txtstring.get(i).getNxt()[1]+","+txtstring.get(i).getSensor());
		        bufWriter.newLine();
		        bufWriter.flush();
	        }
	        bufWriter.close();
	        myWriter.close();
	    } 
	    catch (IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	    }		
	}
	//
    public static void main( String[] args )
    {
    	ArrayList<Sensor> lst = fromJsonSensor(ReadFile(args));
        //for (Sensor s: lst) {
        	//System.out.println(s.battery);
        	//System.out.println(s.reading);
        	//System.out.println(fromJsonWords(ReadCoordinates(s.location)).coordinates.lat);
        //}
        //System.out.println(lst.get(0).reading);
        for (int i = 0; i < lst.size(); i++) {
        	lnglat[i][0] = fromJsonWords(ReadCoordinates(lst.get(i).location,args)).coordinates.lng;
        	lnglat[i][1] = fromJsonWords(ReadCoordinates(lst.get(i).location,args)).coordinates.lat;
        	sensorname[i] = lst.get(i).location;
        	
        }
        //System.out.println(lnglat[0].length);
        Category(lst);
        fromGeojson(ReadGeojson(args));
        setpath();
        //for (int i = 0; i < city1.length; i++) {
        	//for (int j = 0; j < 2; j++) {
        	//	System.out.println(city1[i][j]);
        	//}
        //}
        //System.out.println(" ");
        TwoOpt();
        //for (int i = 0; i < city1.length; i++) {
        	//for (int j = 0; j < 2; j++) {
        		//System.out.println(city1[i][j]);
        	//}
        //}
        setvisitname();
        
        dronepath(initial);
        //System.out.println(dronepath.size());
        //for(int i = 0; i < dronepath.size();i++) {
        	//System.out.println(dronepath.get(i).lng);
        	//System.out.println(dronepath.get(i).lat);
        //}
        SensorMap(lnglat);
        CreateFile(args);
        WriteFile(args);
        CreateFiletxt(args);
        WriteFiletxt(args);
        //for (int i =0; i < 33;i++) {
        	//System.out.println(visitname[i]);
        	//System.out.println(sensorname[i]);
        	//System.out.println(" ");
        //}
        //for(int i = 0; i < dronepath.size();i++) {
        	//System.out.println(dronepath.get(i).lng);
        	//System.out.println(dronepath.get(i).lat);
        	//System.out.println(txtstring.get(i).getCrr()[0]);
        	//System.out.println(txtstring.get(i).getSensor());
        	//System.out.println(" ");
        //}
        //System.out.println(dronepath.size());
        System.out.println(txtstring.size());
        //System.out.println(txtstring.get(93).getCount());
    }
}
