package uk.ac.ed.inf.aqmaps;

public class _tour {
	
	double[][] City = new double[35][2];
	//int tourSize;
	double tourDistance;
	
	protected _tour(double[][] city) {
		this.City = city;
	}
	//generate the [35][2] for 2opt

	protected double[] GetCity(int x) {
		return City[x];
	}
	protected void SetCity(int x, double[] city) {
    	City[x] = city; 
    }
	protected int TourSize() {
		return City.length;
	}
	protected static double Euclidean(double[] current,double[] nextSensor) {
		var output = Math.sqrt(Math.pow((current[0]-nextSensor[0]),2)+Math.pow((current[1]-nextSensor[1]),2));
		return output;
    }
	protected double TourDistance() {
		double out = 0;
		for (int i = 0; i < City.length - 1; i++) {
			out += Euclidean(City[i],City[i+1]);
		}
		return out;
	}

}
