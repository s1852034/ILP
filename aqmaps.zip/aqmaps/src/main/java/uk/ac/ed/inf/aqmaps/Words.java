package uk.ac.ed.inf.aqmaps;

public class Words {
	String country;
	coordinate coordinates;
	square square;
	String nearestPlace;
	String words;
	String language;
	String map;
	
	public static class coordinate{
		double lng;
		double lat;
	}
	
	public static class square{
		coordinate southwest;
		coordinate northeast;
	}

}
