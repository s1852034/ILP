package uk.ac.ed.inf.aqmaps;

public class txt {
	private int count;
	private double[] crr = new double[2];
	private int angle;
	private double[] nxt = new double[2];
	private String sensor;
	public txt(int count, double[] crr, int angle, double[] nxt, String sensor) {
		super();
		this.count = count;
		this.crr = crr;
		this.angle = angle;
		this.nxt = nxt;
		this.sensor = sensor;
	}
	int getCount() {
		return count;
	}
	void setCount(int count) {
		this.count = count;
	}
	double[] getCrr() {
		return crr;
	}
	void setCrr(double[] crr) {
		this.crr = crr;
	}
	int getAngle() {
		return angle;
	}
	void setAngle(int angle) {
		this.angle = angle;
	}
	double[] getNxt() {
		return nxt;
	}
	void setNxt(double[] nxt) {
		this.nxt = nxt;
	}
	String getSensor() {
		return sensor;
	}
	void setSensor(String sensor) {
		this.sensor = sensor;
	}


}
