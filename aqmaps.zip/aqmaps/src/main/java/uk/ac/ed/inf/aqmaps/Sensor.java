package uk.ac.ed.inf.aqmaps;


public class Sensor {
	String location;
	double battery;
	String reading;
}
