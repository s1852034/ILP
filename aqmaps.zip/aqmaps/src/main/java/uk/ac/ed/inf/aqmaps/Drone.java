package uk.ac.ed.inf.aqmaps;


public class Drone {
	private static double[] initial = App.initial;//lng and lat
	private static double[] current = new double[2];
	private static int direction;//multiple of 10 degrees
	private static int direction1;// previous direction
	private static double[][] polygon0 = App.polygon0;
	private static double[][] polygon1 = App.polygon1;
	private static double[][] polygon2 = App.polygon2;
	private static double[][] polygon3 = App.polygon3;
	private static double[][] frame = new double [4][2];
    
	
	//getter and setter
    double[] getInitial() {
		return initial;
	}
	void setInitial(double[] initial) {
		Drone.initial = initial;
	}
	double[] getCurrent() {
		return current;
	}
	void setCurrent(double[] current) {
		Drone.current = current;
	}
    int getDirection() {
		return direction;
	}
	void setDirection(int direction) {
		Drone.direction = direction;
	}
/////////////////////////////////////////////////////////////////////////////	
	//euclidean distance to next sensor
    double DistnextSensor(double[] current,double[] nextSensor) {
		double output = Math.sqrt(Math.pow((current[0]-nextSensor[0]),2)+Math.pow((current[1]-nextSensor[1]),2));
		return output;
	}
	//calculate the position of nextmove
    double[] getnext(int angle, double[] current) {
    	double [] output = new double[2];
    	var anglerad = Math.toRadians(angle);
    	output[0] = ((0.0003)*(Math.cos(anglerad)))+current[0];
    	output[1] = ((0.0003)*(Math.sin(anglerad)))+current[1];
    	return output;
    }
    
	//angle from drone to next sensor
	int getAngle(double[] current,double[] nextSensor) {
	    double angle = Math.toDegrees(Math.atan2(nextSensor[0] - current[0], nextSensor[1] - current[1]));
	    angle = -1*(angle + Math.ceil(-angle/360)*360 - 90);
	    int angle1 = 10*(int) Math.round(angle/10.0);
	    if(angle1 == -0.0) {
	    	angle1 = 0;
	    }
	    if(angle1 < 0) {
	    	angle1 += 360;
	    }
	    if(angle1 == 360) {
	    	angle1 = 0;
	    }
	    return angle1;
	}
	
	
	//whether the drone fall inside no fly zones.
	
	int INF = 10000; 
	  
    class MapPoint  //MapPoint is a MapPoint on the map
    { 
        double x; 
        double y; 
  
        public MapPoint(double x, double y) 
        { 
            this.x = x; 
            this.y = y; 
        } 
    }; 
  
    // Given three colinear MapPoints p, q, r,  
    // the function checks if MapPoint q lies 
    // on line segment 'pr' 
    boolean onSegment(MapPoint p, MapPoint q, MapPoint r)  
    { 
        if (q.x <= Math.max(p.x, r.x) && 
            q.x >= Math.min(p.x, r.x) && 
            q.y <= Math.max(p.y, r.y) && 
            q.y >= Math.min(p.y, r.y)) 
        { 
            return true; 
        } 
        return false; 
    } 
  
    // To find orientation of ordered triplet (p, q, r). 
    // The function returns following values 
    // 0 --> p, q and r are colinear 
    // 1 --> Clockwise 
    // 2 --> Counterclockwise 
    int orientation(MapPoint p, MapPoint q, MapPoint r)  
    { 
        double val = (q.y - p.y) * (r.x - q.x) 
                - (q.x - p.x) * (r.y - q.y); 
  
        if (val == 0)  
        { 
            return 0; // colinear 
        } 
        return (val > 0) ? 1 : 2; // clock or counterclock wise 
    } 
  
    // The function that returns true if  
    // line segment 'p1q1' and 'p2q2' intersect. 
    boolean doIntersect(MapPoint p1, MapPoint q1, MapPoint p2, MapPoint q2)  
    { 
        // Find the four orientations needed for  
        // general and special cases 
        int o1 = orientation(p1, q1, p2); 
        int o2 = orientation(p1, q1, q2); 
        int o3 = orientation(p2, q2, p1); 
        int o4 = orientation(p2, q2, q1); 
  
        // General case 
        if (o1 != o2 && o3 != o4) 
        { 
            return true; 
        } 
  
        // Special Cases 
        // p1, q1 and p2 are colinear and 
        // p2 lies on segment p1q1 
        if (o1 == 0 && onSegment(p1, p2, q1))  
        { 
            return true; 
        } 
  
        // p1, q1 and p2 are colinear and 
        // q2 lies on segment p1q1 
        if (o2 == 0 && onSegment(p1, q2, q1))  
        { 
            return true; 
        } 
  
        // p2, q2 and p1 are colinear and 
        // p1 lies on segment p2q2 
        if (o3 == 0 && onSegment(p2, p1, q2)) 
        { 
            return true; 
        } 
  
        // p2, q2 and q1 are colinear and 
        // q1 lies on segment p2q2 
        if (o4 == 0 && onSegment(p2, q1, q2)) 
        { 
            return true; 
        } 
  
        // Doesn't fall in any of the above cases 
        return false;  
    } 
  
    //check if the path intersect the polygon
    boolean isIntersect(MapPoint polygon[], int n, MapPoint p) 
    { 
        // There must be at least 3 vertices in polygon[] 
        if (n < 3)  
        { 
            return false; 
        } 
  
        // Create a MapPoint for line segment from p to infinite 
        MapPoint crr = new MapPoint(current[0], current[1]); 
  
        // Count intersections of the above line  
        // with sides of polygon 
        int count = 0, i = 0; 
        do 
        { 
            int next = (i + 1) % n; 
  
            // Check if the line segment from 'p' to  
            // 'extreme' intersects with the line  
            // segment from 'polygon[i]' to 'polygon[next]' 
            if (doIntersect(polygon[i], polygon[next], p, crr))  
            { 
                // If the MapPoint 'p' is colinear with line  
                // segment 'i-next', then check if it lies  
                // on segment. If it lies, return true, otherwise false 
                if (orientation(polygon[i], p, polygon[next]) == 0) 
                { 
                    return onSegment(polygon[i], p, 
                                     polygon[next]); 
                } 
  
                count++; 
            } 
            i = next; 
        } while (i != 0); 
  
        // Return true if count is odd, false otherwise 
        return (count > 0); 
    }

    // Returns true if the MapPoint p lies  
    // inside the polygon[] with n vertices 
    boolean isInside(MapPoint polygon[], int n, MapPoint p) 
    { 
        // There must be at least 3 vertices in polygon[] 
        if (n < 3)  
        { 
            return false; 
        } 
  
        // Create a point for line segment from p to infinite 
        MapPoint extreme = new MapPoint(INF, p.y); 
  
        // Count intersections of the above line  
        // with sides of polygon 
        int count = 0, i = 0; 
        do 
        { 
            int next = (i + 1) % n; 
  
            // Check if the line segment from 'p' to  
            // 'extreme' intersects with the line  
            // segment from 'polygon[i]' to 'polygon[next]' 
            if (doIntersect(polygon[i], polygon[next], p, extreme))  
            { 
                // If the point 'p' is colinear with line  
                // segment 'i-next', then check if it lies  
                // on segment. If it lies, return true, otherwise false 
                if (orientation(polygon[i], p, polygon[next]) == 0) 
                { 
                    return onSegment(polygon[i], p, 
                                     polygon[next]); 
                } 
  
                count++; 
            } 
            i = next; 
        } while (i != 0); 
  
        // Return true if count is odd, false otherwise 
        return (count % 2 == 1); // Same as (count%2 == 1) 
    } 
    // check if drone is inside any no_fly_zone
    void putframe() {
    	frame[3][1] = 55.946233;
    	frame[3][0] = -3.192473;
    	frame[0][1] = 55.942617;
    	frame[0][0] = -3.192473;
    	frame[1][1] = 55.942617;
    	frame[1][0] = -3.184319;
    	frame[2][1] = 55.946233;
    	frame[2][0] = -3.184319;
    }
    boolean isInside_nfz(double[] current) {
    	//for frame
    	putframe();
    	MapPoint fr[] = new MapPoint[4];
    	for (int i = 0; i < frame.length; i ++) {
    		fr[i] = new MapPoint(frame[i][0],frame[i][1]);
    	}
    	//
    	MapPoint p = new MapPoint(current[0],current[1]);
    	MapPoint plg0[] = new MapPoint[14];
    	MapPoint plg1[] = new MapPoint[4];
    	MapPoint plg2[] = new MapPoint[4];
    	MapPoint plg3[] = new MapPoint[10];
    	//polygon0
    	for (int i = 0; i < polygon0.length-1; i ++) {
    		plg0[i] = new MapPoint(polygon0[i][0],polygon0[i][1]);
    	}
    	for (int i = 0; i < polygon1.length-1; i ++) {
    		plg1[i] = new MapPoint(polygon1[i][0],polygon1[i][1]);
    	}
    	for (int i = 0; i < polygon2.length-1; i ++) {
    		plg2[i] = new MapPoint(polygon2[i][0],polygon2[i][1]);
    	}
    	for (int i = 0; i < polygon3.length-1; i ++) {
    		plg3[i] = new MapPoint(polygon3[i][0],polygon3[i][1]);
    	}
    	if(isInside(plg0,polygon0.length-1,p)||isInside(plg1,polygon1.length-1,p)||isInside(plg2,polygon2.length-1,p)||isInside(plg3,polygon3.length-1,p)||!(isInside(fr,frame.length,p))) {
    		return true;
    	}else if(isIntersect(plg0,polygon0.length-1,p)||isIntersect(plg1,polygon1.length-1,p)||isIntersect(plg2,polygon2.length-1,p)||isIntersect(plg3,polygon3.length-1,p)){
    		return true;
    	}else {
    		return false;
    	}
    }
    
	void move(double[]crr, double[]nextSensor) {
        direction1 = direction;
		direction = getAngle(crr,nextSensor);
        current = crr;
    	while(isInside_nfz(getnext(direction,crr))) {
    		direction -= 30;
            if (Math.abs(direction - direction1) == 180 ) {
            	direction -=70;
            }
            if(direction < 0) {
            	direction += 360;
            }
            if (direction >= 360) {
            	direction -= 360; 
            }
    	}
    	current = getnext(direction,crr);
    }
	
}
